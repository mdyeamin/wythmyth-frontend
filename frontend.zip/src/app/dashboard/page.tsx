"use client";

import { useEffect } from "react";
import { useSelector } from "react-redux";
import { useRouter } from "next/navigation";

export default function DashboardPage() {
  const router = useRouter();
  const user = useSelector((state: any) => state.auth.user);

  useEffect(() => {
    // 🔐 user না থাকলে login
    if (user === null) {
      router.replace("/login");
      return;
    }

    // ✅ user থাকলে default sub-route
    router.replace("/dashboard/profile");
  }, [user, router]);

  return null; // loader চাইলে এখানে দিতে পারো
}
