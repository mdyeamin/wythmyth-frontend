"use client";

import { useSelector } from "react-redux";
import { useRouter } from "next/navigation";
import { useEffect } from "react";

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const user = useSelector((state: any) => state.auth.user);

  useEffect(() => {
    if (!user) router.replace("/login");
  }, [user, router]);

  if (!user) return null;

  return (
    <div className="flex min-h-screen">
      {/* sidebar */}
      <aside className="w-64 border-r p-4">Sidebar</aside>

      {/* content */}
      <main className="flex-1 p-6">{children}</main>
    </div>
  );
}
