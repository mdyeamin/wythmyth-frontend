export default function SettingsPage() {
  return (
    <div>
      <h1 className="text-xl font-semibold mb-2">Settings</h1>
      <p>Settings content here</p>
    </div>
  );
}
