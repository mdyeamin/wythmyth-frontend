import ForgotPasswordForm from "../components/ui/forgot-password-form";

export default function Page() {
  return <ForgotPasswordForm />;
}
