"use client";

import { cn } from "../../lib/utils";
import { Button } from "./ui/button";
import { FaGithub } from "react-icons/fa";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { loginSchema, LoginFormValues } from "../../validations/loginSchema";

import {
  Field,
  FieldDescription,
  FieldGroup,
  FieldLabel,
  FieldSeparator,
} from "./ui/field";
import { Input } from "./ui/input";
import Link from "next/link";

import { useRouter } from "next/navigation";
import { useDispatch } from "react-redux";
import { useLoginMutation } from "../../lib/api/authApi";
import { setCredentials } from "../../lib/auth/authSlice";

export function LoginForm({
  className,
  ...props
}: React.ComponentProps<"form">) {
  const router = useRouter();
  const dispatch = useDispatch();

  const [login, { isLoading, error }] = useLoginMutation();

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
    setError,
  } = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
    },
    mode: "onSubmit",
  });

  const onInvalid = (errs: any) => {
    console.log("FORM INVALID ❌", errs);
  };

  const onSubmit = async (data: LoginFormValues) => {
    console.log("LOGIN SUBMIT ✅", data);

    try {
      // ✅ backend expects: { email, password }
      const payload = {
        email: data.email,
        password: data.password,
      };

      const res = await login(payload).unwrap();

      // ✅ save token/user etc (as your slice expects)
      dispatch(setCredentials(res));

      router.push("/"); // or "/dashboard"
    } catch (err: any) {
      const apiData = err?.data;

      // common backend patterns
      if (apiData?.detail) {
        setError("password", { type: "server", message: apiData.detail });
      } else if (apiData?.message) {
        setError("password", { type: "server", message: apiData.message });
      } else if (apiData?.non_field_errors?.[0]) {
        setError("password", {
          type: "server",
          message: apiData.non_field_errors[0],
        });
      } else if (apiData?.email?.[0]) {
        setError("email", { type: "server", message: apiData.email[0] });
      } else if (apiData?.password?.[0]) {
        setError("password", { type: "server", message: apiData.password[0] });
      }

      console.log("Login failed:", err);
    }
  };

  return (
    <form
      className={cn("flex flex-col gap-6", className)}
      onSubmit={handleSubmit(onSubmit, onInvalid)}
      {...props}
      noValidate
    >
      <FieldGroup>
        <div className="flex flex-col items-center gap-1 text-center">
          <h1 className="text-2xl font-bold">Login to your account</h1>
          <p className="text-muted-foreground text-sm text-balance">
            Enter your email below to login to your account
          </p>
        </div>

        {error && (
          <div className="rounded-md border border-red-500/40 bg-red-500/10 p-3 text-sm text-red-600">
            <pre className="whitespace-pre-wrap">
              {JSON.stringify((error as any)?.data ?? error, null, 2)}
            </pre>
          </div>
        )}

        <Field>
          <FieldLabel htmlFor="email" className="mb-2">
            Email
          </FieldLabel>
          <Input
            id="email"
            type="email"
            placeholder="m@example.com"
            {...register("email")}
          />
          {errors.email && (
            <p className="mt-1 text-sm text-red-500">{errors.email.message}</p>
          )}
        </Field>

        <Field>
          <div className="flex items-center">
            <FieldLabel htmlFor="password" className="mb-2">
              Password
            </FieldLabel>
            <Link
              href="/forgot-password"
              className="mb-2 ml-auto text-sm underline-offset-4 hover:underline"
            >
              Forgot your password?
            </Link>
          </div>

          <Input
            id="password"
            type="password"
            placeholder="Enter your password"
            {...register("password")}
          />

          {errors.password && (
            <p className="mt-1 text-sm text-red-500">
              {errors.password.message}
            </p>
          )}
        </Field>

        <Field>
          <Button
            type="submit"
            disabled={isSubmitting || isLoading}
            className="w-full"
          >
            {isSubmitting || isLoading ? "Logging in..." : "Login"}
          </Button>
        </Field>

        <FieldSeparator>Or continue with</FieldSeparator>

        <Field>
          <Button
            variant="outline"
            type="button"
            className="flex items-center gap-2"
          >
            <FaGithub className="h-5 w-5" />
            Login with GitHub
          </Button>

          <FieldDescription className="text-center">
            Don&apos;t have an account?{" "}
            <Link href="/register" className="underline underline-offset-4">
              Sign up
            </Link>
          </FieldDescription>
        </Field>
      </FieldGroup>
    </form>
  );
}
