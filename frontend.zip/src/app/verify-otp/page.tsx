import VerifyOtpForm from "../components/verify-otp-form";

export default function VerifyOtpPage() {
  return (
    <div className="mx-auto max-w-md p-6">
      <VerifyOtpForm />
    </div>
  );
}
