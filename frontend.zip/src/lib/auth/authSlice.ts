import { createSlice, PayloadAction } from "@reduxjs/toolkit";

type AuthState = {
  user: any | null;
};

const initialState: AuthState = {
  user: null,
};

const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    // ✅ Login / current-user hydrate
    setUser: (state, action: PayloadAction<any>) => {
      state.user = action.payload;
    },

    // 🚪 Logout / clear user
    logout: (state) => {
      state.user = null;
    },

    // 🔄 alias for hydrator / consistency
    clearUser: (state) => {
      state.user = null;
    },
  },
});

export const { setUser, logout, clearUser } = authSlice.actions;
export default authSlice.reducer;
