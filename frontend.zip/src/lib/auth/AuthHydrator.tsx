"use client";

import { useEffect, useRef } from "react";
import { useDispatch } from "react-redux";
import { useCurrentUserQuery } from "../api/authApi";
import { setUser, clearUser } from "./authSlice";

export default function AuthHydrator() {
  const dispatch = useDispatch();

  const { data, error, isFetching, isLoading, isSuccess } = useCurrentUserQuery();

  // ✅ prevent repeated dispatch (dev strict mode)
  const hydratedOnce = useRef(false);

  useEffect(() => {
    // ✅ success হলে user set (only once)
    if (!hydratedOnce.current && isSuccess && data?.success && data?.data?.user) {
      dispatch(setUser(data.data.user));
      hydratedOnce.current = true;
      return;
    }

    // ✅ request শেষ হওয়ার পরেই error হলে clear
    const requestDone = !isLoading && !isFetching;

    if (requestDone && error) {
      dispatch(clearUser());
      hydratedOnce.current = true;
    }
  }, [data, error, isFetching, isLoading, isSuccess, dispatch]);

  return null;
}
