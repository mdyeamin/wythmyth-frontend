module.exports = [
"[project]/.next-internal/server/app/reset-password/[uid]/[token]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_reset-password_%5Buid%5D_%5Btoken%5D_page_actions_ee93e31e.js.map