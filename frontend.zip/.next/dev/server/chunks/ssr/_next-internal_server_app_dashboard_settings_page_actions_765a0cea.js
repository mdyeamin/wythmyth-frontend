module.exports = [
"[project]/.next-internal/server/app/dashboard/settings/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_dashboard_settings_page_actions_765a0cea.js.map