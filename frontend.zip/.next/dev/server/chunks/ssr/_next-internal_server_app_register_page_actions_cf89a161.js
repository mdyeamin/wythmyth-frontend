module.exports = [
"[project]/.next-internal/server/app/register/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_register_page_actions_cf89a161.js.map