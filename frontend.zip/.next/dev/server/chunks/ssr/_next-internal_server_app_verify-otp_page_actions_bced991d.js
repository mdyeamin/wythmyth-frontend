module.exports = [
"[project]/.next-internal/server/app/verify-otp/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_verify-otp_page_actions_bced991d.js.map