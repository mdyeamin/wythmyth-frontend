module.exports = [
"[project]/src/lib/api/authApi.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "authApi",
    ()=>authApi,
    "useCurrentUserQuery",
    ()=>useCurrentUserQuery,
    "useLoginMutation",
    ()=>useLoginMutation,
    "useLogoutMutation",
    ()=>useLogoutMutation,
    "useRefreshTokenMutation",
    ()=>useRefreshTokenMutation,
    "useResendOtpMutation",
    ()=>useResendOtpMutation,
    "useResetPasswordMutation",
    ()=>useResetPasswordMutation,
    "useSendResetPasswordEmailMutation",
    ()=>useSendResetPasswordEmailMutation,
    "useSignupMutation",
    ()=>useSignupMutation,
    "useVerifyEmailMutation",
    ()=>useVerifyEmailMutation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2f$baseApi$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/api/baseApi.ts [app-ssr] (ecmascript)");
;
const authApi = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2f$baseApi$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["baseApi"].injectEndpoints({
    endpoints: (builder)=>({
            // ✅ SIGNUP: /api/auth/signup/
            signup: builder.mutation({
                query: (body)=>({
                        url: "/api/auth/signup/",
                        method: "POST",
                        body
                    })
            }),
            // ✅ VERIFY EMAIL/OTP: /api/auth/verify-email/
            verifyEmail: builder.mutation({
                query: (body)=>({
                        url: "/api/auth/verify-email/",
                        method: "POST",
                        body
                    })
            }),
            // ✅ RESEND OTP: /api/auth/resend-otp/
            resendOtp: builder.mutation({
                query: (body)=>({
                        url: "/api/auth/resend-otp/",
                        method: "POST",
                        body
                    })
            }),
            // ✅ LOGIN: /api/auth/login/
            login: builder.mutation({
                query: (body)=>({
                        url: "/api/auth/login/",
                        method: "POST",
                        body
                    })
            }),
            // ✅ CURRENT USER: /api/auth/current-user/
            currentUser: builder.query({
                query: ()=>({
                        url: "/api/auth/current-user/",
                        method: "GET"
                    })
            }),
            // ✅ LOGOUT: /api/auth/logout/
            logout: builder.mutation({
                query: ()=>({
                        url: "/api/auth/logout/",
                        method: "POST"
                    })
            }),
            // ✅ TOKEN REFRESH (cookie based): /api/auth/token/refresh/
            refreshToken: builder.mutation({
                query: ()=>({
                        url: "/api/auth/token/refresh/",
                        method: "POST"
                    })
            }),
            // ✅ SEND RESET EMAIL: /api/auth/send-reset-password-email/
            sendResetPasswordEmail: builder.mutation({
                query: (body)=>({
                        url: "/api/auth/send-reset-password-email/",
                        method: "POST",
                        body
                    })
            }),
            // ✅ RESET PASSWORD: /api/auth/reset-password/{uid}/{token}/
            resetPassword: builder.mutation({
                query: ({ uid, token, ...body })=>({
                        url: `/api/auth/reset-password/${uid}/${token}/`,
                        method: "POST",
                        body
                    })
            })
        })
});
const { useSignupMutation, useVerifyEmailMutation, useResendOtpMutation, useLoginMutation, useCurrentUserQuery, useLogoutMutation, useRefreshTokenMutation, useSendResetPasswordEmailMutation, useResetPasswordMutation } = authApi;
}),
"[project]/src/app/components/ui/forgot-password-form.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ForgotPasswordForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2f$authApi$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/api/authApi.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
function ForgotPasswordForm() {
    const [email, setEmail] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [msg, setMsg] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [sendReset, { isLoading, error }] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2f$authApi$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSendResetPasswordEmailMutation"])();
    const submit = async (e)=>{
        e.preventDefault();
        setMsg(null);
        try {
            await sendReset({
                email
            }).unwrap();
            setMsg("✅ Reset link sent. Please check your email.");
        } catch (e) {
            setMsg(e?.data?.message || "❌ Failed to send reset email.");
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
        onSubmit: submit,
        className: "space-y-3",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                type: "email",
                placeholder: "Enter your email",
                value: email,
                onChange: (e)=>setEmail(e.target.value)
            }, void 0, false, {
                fileName: "[project]/src/app/components/ui/forgot-password-form.tsx",
                lineNumber: 26,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                disabled: isLoading,
                children: isLoading ? "Sending..." : "Send reset link"
            }, void 0, false, {
                fileName: "[project]/src/app/components/ui/forgot-password-form.tsx",
                lineNumber: 33,
                columnNumber: 7
            }, this),
            msg && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                children: msg
            }, void 0, false, {
                fileName: "[project]/src/app/components/ui/forgot-password-form.tsx",
                lineNumber: 37,
                columnNumber: 15
            }, this),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("pre", {
                children: JSON.stringify(error?.data ?? error, null, 2)
            }, void 0, false, {
                fileName: "[project]/src/app/components/ui/forgot-password-form.tsx",
                lineNumber: 38,
                columnNumber: 17
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/components/ui/forgot-password-form.tsx",
        lineNumber: 25,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=src_401e21ec._.js.map