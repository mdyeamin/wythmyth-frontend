module.exports = [
"[project]/src/app/dashboard/layout.tsx [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=src_app_dashboard_layout_tsx_3fd7cd9c._.js.map