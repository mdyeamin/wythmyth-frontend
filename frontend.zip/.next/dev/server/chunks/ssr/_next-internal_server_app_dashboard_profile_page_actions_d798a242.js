module.exports = [
"[project]/.next-internal/server/app/dashboard/profile/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_dashboard_profile_page_actions_d798a242.js.map