(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/app/components/ui/reset-password-form.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ResetPasswordForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2f$authApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/api/authApi.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function ResetPasswordForm(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(31);
    if ($[0] !== "2e98c3875e8851a3263e368da3987e376b18124013951ad0fde2a9818ecef6c8") {
        for(let $i = 0; $i < 31; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "2e98c3875e8851a3263e368da3987e376b18124013951ad0fde2a9818ecef6c8";
    }
    const { uid, token } = t0;
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    console.log("uid:", uid);
    console.log("token:", token);
    const [password, setPassword] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [password2, setPassword2] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [msg, setMsg] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [resetPassword, t1] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2f$authApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useResetPasswordMutation"])();
    const { isLoading, error } = t1;
    let t2;
    bb0: {
        const e = error;
        const data = e?.data;
        if (!data) {
            t2 = null;
            break bb0;
        }
        if (typeof data === "string") {
            t2 = data;
            break bb0;
        }
        if (data?.message) {
            t2 = data.message;
            break bb0;
        }
        if (data?.detail) {
            t2 = data.detail;
            break bb0;
        }
        try {
            let t3;
            if ($[1] !== data) {
                t3 = JSON.stringify(data, null, 2);
                $[1] = data;
                $[2] = t3;
            } else {
                t3 = $[2];
            }
            t2 = t3;
        } catch  {
            t2 = "Something went wrong.";
        }
    }
    const serverErrorText = t2;
    let t3;
    if ($[3] !== password || $[4] !== password2 || $[5] !== resetPassword || $[6] !== router || $[7] !== token || $[8] !== uid) {
        t3 = ({
            "ResetPasswordForm[submit]": async (e_0)=>{
                e_0.preventDefault();
                setMsg(null);
                if (!uid || !token) {
                    setMsg("\u274C Invalid reset link (uid/token missing). Please request again.");
                    return;
                }
                if (password.length < 8) {
                    setMsg("Password must be at least 8 characters.");
                    return;
                }
                if (password !== password2) {
                    setMsg("Passwords do not match.");
                    return;
                }
                try {
                    await resetPassword({
                        uid,
                        token,
                        password,
                        password2
                    }).unwrap();
                    setMsg("\u2705 Password reset successful! Redirecting to login...");
                    router.replace("/login");
                } catch  {}
            }
        })["ResetPasswordForm[submit]"];
        $[3] = password;
        $[4] = password2;
        $[5] = resetPassword;
        $[6] = router;
        $[7] = token;
        $[8] = uid;
        $[9] = t3;
    } else {
        t3 = $[9];
    }
    const submit = t3;
    let t4;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
            className: "text-xl font-semibold",
            children: "Reset Password"
        }, void 0, false, {
            fileName: "[project]/src/app/components/ui/reset-password-form.tsx",
            lineNumber: 108,
            columnNumber: 10
        }, this);
        $[10] = t4;
    } else {
        t4 = $[10];
    }
    let t5;
    if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = ({
            "ResetPasswordForm[<input>.onChange]": (e_1)=>setPassword(e_1.target.value)
        })["ResetPasswordForm[<input>.onChange]"];
        $[11] = t5;
    } else {
        t5 = $[11];
    }
    let t6;
    if ($[12] !== password) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
            className: "w-full rounded border p-2",
            type: "password",
            value: password,
            placeholder: "New password",
            onChange: t5
        }, void 0, false, {
            fileName: "[project]/src/app/components/ui/reset-password-form.tsx",
            lineNumber: 124,
            columnNumber: 10
        }, this);
        $[12] = password;
        $[13] = t6;
    } else {
        t6 = $[13];
    }
    let t7;
    if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = ({
            "ResetPasswordForm[<input>.onChange]": (e_2)=>setPassword2(e_2.target.value)
        })["ResetPasswordForm[<input>.onChange]"];
        $[14] = t7;
    } else {
        t7 = $[14];
    }
    let t8;
    if ($[15] !== password2) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
            className: "w-full rounded border p-2",
            type: "password",
            value: password2,
            placeholder: "Confirm new password",
            onChange: t7
        }, void 0, false, {
            fileName: "[project]/src/app/components/ui/reset-password-form.tsx",
            lineNumber: 141,
            columnNumber: 10
        }, this);
        $[15] = password2;
        $[16] = t8;
    } else {
        t8 = $[16];
    }
    const t9 = isLoading ? "Resetting..." : "Reset Password";
    let t10;
    if ($[17] !== isLoading || $[18] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "submit",
            disabled: isLoading,
            className: "w-full rounded bg-black px-4 py-2 text-white disabled:opacity-60",
            children: t9
        }, void 0, false, {
            fileName: "[project]/src/app/components/ui/reset-password-form.tsx",
            lineNumber: 150,
            columnNumber: 11
        }, this);
        $[17] = isLoading;
        $[18] = t9;
        $[19] = t10;
    } else {
        t10 = $[19];
    }
    let t11;
    if ($[20] !== msg) {
        t11 = msg && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-sm",
            children: msg
        }, void 0, false, {
            fileName: "[project]/src/app/components/ui/reset-password-form.tsx",
            lineNumber: 159,
            columnNumber: 18
        }, this);
        $[20] = msg;
        $[21] = t11;
    } else {
        t11 = $[21];
    }
    let t12;
    if ($[22] !== serverErrorText) {
        t12 = serverErrorText && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "rounded border border-red-500/40 bg-red-500/10 p-3 text-sm text-red-600",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("pre", {
                className: "whitespace-pre-wrap",
                children: serverErrorText
            }, void 0, false, {
                fileName: "[project]/src/app/components/ui/reset-password-form.tsx",
                lineNumber: 167,
                columnNumber: 119
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/components/ui/reset-password-form.tsx",
            lineNumber: 167,
            columnNumber: 30
        }, this);
        $[22] = serverErrorText;
        $[23] = t12;
    } else {
        t12 = $[23];
    }
    let t13;
    if ($[24] !== submit || $[25] !== t10 || $[26] !== t11 || $[27] !== t12 || $[28] !== t6 || $[29] !== t8) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
            onSubmit: submit,
            className: "space-y-3 max-w-md",
            children: [
                t4,
                t6,
                t8,
                t10,
                t11,
                t12
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/components/ui/reset-password-form.tsx",
            lineNumber: 175,
            columnNumber: 11
        }, this);
        $[24] = submit;
        $[25] = t10;
        $[26] = t11;
        $[27] = t12;
        $[28] = t6;
        $[29] = t8;
        $[30] = t13;
    } else {
        t13 = $[30];
    }
    return t13;
}
_s(ResetPasswordForm, "09BEkshiKXUI34dfFFcjrbecrBU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2f$authApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useResetPasswordMutation"]
    ];
});
_c = ResetPasswordForm;
var _c;
__turbopack_context__.k.register(_c, "ResetPasswordForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/node_modules/next/navigation.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = __turbopack_context__.r("[project]/node_modules/next/dist/client/components/navigation.js [app-client] (ecmascript)");
}),
]);

//# sourceMappingURL=_bf3b9c1c._.js.map