(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_48d562cc._.js",
  "static/chunks/src_0f08f295._.js"
],
    source: "dynamic"
});
