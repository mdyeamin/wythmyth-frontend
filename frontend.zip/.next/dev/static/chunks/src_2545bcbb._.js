(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/lib/api/authApi.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "authApi",
    ()=>authApi,
    "useCurrentUserQuery",
    ()=>useCurrentUserQuery,
    "useLoginMutation",
    ()=>useLoginMutation,
    "useLogoutMutation",
    ()=>useLogoutMutation,
    "useRefreshTokenMutation",
    ()=>useRefreshTokenMutation,
    "useResendOtpMutation",
    ()=>useResendOtpMutation,
    "useResetPasswordMutation",
    ()=>useResetPasswordMutation,
    "useSendResetPasswordEmailMutation",
    ()=>useSendResetPasswordEmailMutation,
    "useSignupMutation",
    ()=>useSignupMutation,
    "useVerifyEmailMutation",
    ()=>useVerifyEmailMutation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2f$baseApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/api/baseApi.ts [app-client] (ecmascript)");
;
const authApi = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2f$baseApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["baseApi"].injectEndpoints({
    endpoints: (builder)=>({
            // ✅ SIGNUP: /api/auth/signup/
            signup: builder.mutation({
                query: (body)=>({
                        url: "/api/auth/signup/",
                        method: "POST",
                        body
                    })
            }),
            // ✅ VERIFY EMAIL/OTP: /api/auth/verify-email/
            verifyEmail: builder.mutation({
                query: (body)=>({
                        url: "/api/auth/verify-email/",
                        method: "POST",
                        body
                    })
            }),
            // ✅ RESEND OTP: /api/auth/resend-otp/
            resendOtp: builder.mutation({
                query: (body)=>({
                        url: "/api/auth/resend-otp/",
                        method: "POST",
                        body
                    })
            }),
            // ✅ LOGIN: /api/auth/login/
            login: builder.mutation({
                query: (body)=>({
                        url: "/api/auth/login/",
                        method: "POST",
                        body
                    })
            }),
            // ✅ CURRENT USER: /api/auth/current-user/
            currentUser: builder.query({
                query: ()=>({
                        url: "/api/auth/current-user/",
                        method: "GET"
                    })
            }),
            // ✅ LOGOUT: /api/auth/logout/
            logout: builder.mutation({
                query: ()=>({
                        url: "/api/auth/logout/",
                        method: "POST"
                    })
            }),
            // ✅ TOKEN REFRESH (cookie based): /api/auth/token/refresh/
            refreshToken: builder.mutation({
                query: ()=>({
                        url: "/api/auth/token/refresh/",
                        method: "POST"
                    })
            }),
            // ✅ SEND RESET EMAIL: /api/auth/send-reset-password-email/
            sendResetPasswordEmail: builder.mutation({
                query: (body)=>({
                        url: "/api/auth/send-reset-password-email/",
                        method: "POST",
                        body
                    })
            }),
            // ✅ RESET PASSWORD: /api/auth/reset-password/{uid}/{token}/
            resetPassword: builder.mutation({
                query: ({ uid, token, ...body })=>({
                        url: `/api/auth/reset-password/${uid}/${token}/`,
                        method: "POST",
                        body
                    })
            })
        })
});
const { useSignupMutation, useVerifyEmailMutation, useResendOtpMutation, useLoginMutation, useCurrentUserQuery, useLogoutMutation, useRefreshTokenMutation, useSendResetPasswordEmailMutation, useResetPasswordMutation } = authApi;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/components/ui/forgot-password-form.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ForgotPasswordForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2f$authApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/api/authApi.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function ForgotPasswordForm() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(20);
    if ($[0] !== "3c6a043df6f08f4c4c65e8d9c4b610f3b041bee18f243f744425039c163f87ad") {
        for(let $i = 0; $i < 20; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "3c6a043df6f08f4c4c65e8d9c4b610f3b041bee18f243f744425039c163f87ad";
    }
    const [email, setEmail] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [msg, setMsg] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [sendReset, t0] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2f$authApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSendResetPasswordEmailMutation"])();
    const { isLoading, error } = t0;
    let t1;
    if ($[1] !== email || $[2] !== sendReset) {
        t1 = ({
            "ForgotPasswordForm[submit]": async (e)=>{
                e.preventDefault();
                setMsg(null);
                ;
                try {
                    await sendReset({
                        email
                    }).unwrap();
                    setMsg("\u2705 Reset link sent. Please check your email.");
                } catch (t2) {
                    const e_0 = t2;
                    setMsg(e_0?.data?.message || "\u274C Failed to send reset email.");
                }
            }
        })["ForgotPasswordForm[submit]"];
        $[1] = email;
        $[2] = sendReset;
        $[3] = t1;
    } else {
        t1 = $[3];
    }
    const submit = t1;
    let t2;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = ({
            "ForgotPasswordForm[<input>.onChange]": (e_1)=>setEmail(e_1.target.value)
        })["ForgotPasswordForm[<input>.onChange]"];
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    let t3;
    if ($[5] !== email) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
            type: "email",
            placeholder: "Enter your email",
            value: email,
            onChange: t2
        }, void 0, false, {
            fileName: "[project]/src/app/components/ui/forgot-password-form.tsx",
            lineNumber: 57,
            columnNumber: 10
        }, this);
        $[5] = email;
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    const t4 = isLoading ? "Sending..." : "Send reset link";
    let t5;
    if ($[7] !== isLoading || $[8] !== t4) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            disabled: isLoading,
            children: t4
        }, void 0, false, {
            fileName: "[project]/src/app/components/ui/forgot-password-form.tsx",
            lineNumber: 66,
            columnNumber: 10
        }, this);
        $[7] = isLoading;
        $[8] = t4;
        $[9] = t5;
    } else {
        t5 = $[9];
    }
    let t6;
    if ($[10] !== msg) {
        t6 = msg && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            children: msg
        }, void 0, false, {
            fileName: "[project]/src/app/components/ui/forgot-password-form.tsx",
            lineNumber: 75,
            columnNumber: 17
        }, this);
        $[10] = msg;
        $[11] = t6;
    } else {
        t6 = $[11];
    }
    let t7;
    if ($[12] !== error) {
        t7 = error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("pre", {
            children: JSON.stringify(error?.data ?? error, null, 2)
        }, void 0, false, {
            fileName: "[project]/src/app/components/ui/forgot-password-form.tsx",
            lineNumber: 83,
            columnNumber: 19
        }, this);
        $[12] = error;
        $[13] = t7;
    } else {
        t7 = $[13];
    }
    let t8;
    if ($[14] !== submit || $[15] !== t3 || $[16] !== t5 || $[17] !== t6 || $[18] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
            onSubmit: submit,
            className: "space-y-3",
            children: [
                t3,
                t5,
                t6,
                t7
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/components/ui/forgot-password-form.tsx",
            lineNumber: 91,
            columnNumber: 10
        }, this);
        $[14] = submit;
        $[15] = t3;
        $[16] = t5;
        $[17] = t6;
        $[18] = t7;
        $[19] = t8;
    } else {
        t8 = $[19];
    }
    return t8;
}
_s(ForgotPasswordForm, "7J1e8ymhL4Qk7HHTzb1qXOCcNBk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2f$authApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSendResetPasswordEmailMutation"]
    ];
});
_c = ForgotPasswordForm;
var _c;
__turbopack_context__.k.register(_c, "ForgotPasswordForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_2545bcbb._.js.map