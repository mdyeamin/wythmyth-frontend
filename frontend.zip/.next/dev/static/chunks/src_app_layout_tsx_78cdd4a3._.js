(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__0f0ba101._.css",
  "static/chunks/node_modules_10e75c74._.js",
  "static/chunks/src_lib_d3be5786._.js"
],
    source: "dynamic"
});
