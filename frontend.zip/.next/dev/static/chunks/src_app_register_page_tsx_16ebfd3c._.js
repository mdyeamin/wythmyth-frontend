(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_56b6fd65._.js",
  "static/chunks/node_modules_react-icons_fa_index_mjs_0459ff00._.js",
  "static/chunks/node_modules_react-icons_lib_844c6c50._.js",
  "static/chunks/node_modules_zod_v4_c222d447._.js",
  "static/chunks/node_modules_d97beabe._.js",
  "static/chunks/src_cad8cd11._.js"
],
    source: "dynamic"
});
